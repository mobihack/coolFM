<?php
// Run the recursive function


// This function scans the files folder recursively, and builds a large array



// Output the directory listing as JSON


?>